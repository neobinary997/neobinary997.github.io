# 博客项目结构与发布规范

## 项目目录结构

```
优质技术文章解读沉淀/            # 项目根（git 仓库，远程 origin → neobinary997/neobinary997.github.io）
├── 文章解读/                   # 【源目录】解读文章的原始 Markdown（命名 YYYY-MM-DD-标题.md）
├── docs/                       # VitePress 站点源
│   ├── index.md                # 首页（hero + features 布局）
│   ├── about.md                # 关于页
│   ├── public/logo.svg         # 站点图标
│   ├── posts/                  # 【博客文章目录】已发布的文章
│   │   ├── index.md            # 文章列表页（脚本自动维护）
│   │   └── YYYY-MM-DD-标题.md  # 已发布文章（含 frontmatter）
│   └── .vitepress/
│       ├── config.mjs          # 站点配置：导航、侧边栏、搜索、i18n（侧边栏手动维护）
│       └── dist/               # 构建产物（不入库）
├── .github/workflows/deploy.yml # GitHub Actions 自动部署工作流
└── package.json                # vitepress 依赖与 dev/build/preview 脚本
```

## Frontmatter 规范

每篇博客文章顶部必须有 YAML frontmatter（`---` 包裹）：

```yaml
---
title: 文章标题
date: 2026-08-07
tags:
  - AI Agent
category: AI Agent
description: 一句话描述，用于搜索与分享预览
---
```

- `title`：含特殊字符（如 `:`、`#`、引号）时必须加引号包裹。
- `date`：YYYY-MM-DD 格式。
- `category`：目前约定分类为 `AI Agent` / `其他`，可扩展。
- `description`：可选，建议写文章核心价值一句话。

## 常见问题排查

### 构建失败
- **frontmatter 语法错误**：`title` 含冒号等特殊字符未加引号 → 加引号。
- **中文路径问题**：文件名含中文/空格在部分场景需 URL 编码，link 使用文章文件名主体（不带 .md）。
- **依赖问题**：`npm ci` 失败时先删除 node_modules 和 package-lock.json 再 `npm install`。

### 分类不准确
脚本按关键词自动归类，发布后检查 frontmatter 的 `category`，不准用 Edit 修正，并同步更新 `docs/posts/index.md` 中的分组。

### 文章 404
- 检查 `docs/posts/` 是否真的有该文件；
- 检查 config.mjs 侧边栏 link 是否与文件名主体一致（无 `.md` 后缀，cleanUrls 生效）；
- 部署后需等 1-2 分钟 Actions 跑完，先 `gh run list` 确认部署状态。

### 部署失败
- 打开 GitHub 仓库 Actions 页面查看日志；
- 常见原因：构建报错（同上）、Pages 构建源未设为 workflow 模式（Settings → Pages → Build and deployment → Source: GitHub Actions）。

## 常用命令

```bash
npm run dev        # 本地开发预览（http://localhost:5173）
npm run build      # 构建生产站点到 docs/.vitepress/dist
npm run preview    # 本地预览构建产物
gh run list --repo neobinary997/neobinary997.github.io   # 查看部署状态
```
