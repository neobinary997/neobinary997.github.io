---
name: publish-article-to-blog
description: 将写好的文章发布到基于 VitePress + GitHub Pages 的个人技术博客。当用户在「优质技术文章解读沉淀」项目中写完解读文章（存于 文章解读/ 目录）并希望它上线到 https://neobinary997.github.io 博客时使用。触发场景："发布这篇文章到博客"、"把文章推上线"、"更新博客"、"写好了帮我发布"。技能自动完成：迁移文章到 docs/posts/、生成 frontmatter、更新文章列表与侧边栏、本地构建验证、git 提交并推送触发 GitHub Actions 自动部署。
agent_created: true
---

# Publish Article To Blog

## Overview

将 `文章解读/` 目录下写好的 Markdown 文章发布到本项目的 VitePress 博客（`docs/`），推送到 GitHub 仓库 `neobinary997/neobinary997.github.io` 后由 GitHub Actions 自动构建并部署到 GitHub Pages。

**发布链路**：`文章解读/*.md` → 迁移到 `docs/posts/` + 补 frontmatter → 更新文章列表 & 侧边栏 → `npm run build` 验证 → git 提交推送 → Actions 自动部署（约 1-2 分钟生效）。

## Workflow

### Step 1: 识别待发布文章

- 阅读 `文章解读/` 目录，确认用户想发布的文章（可能指定文件名，也可能要求全部）。
- 用 `scripts/publish.py` 全量扫描，它会自动跳过已在 `docs/posts/` 中存在的文章（已发布），只处理新文章。

```bash
python3 .workbuddy/skills/publish-article-to-blog/scripts/publish.py --dry-run
```

- 先跑 `--dry-run` 预览将要发布哪些文章、生成什么 frontmatter，确认无误后再执行。

### Step 2: 执行发布脚本

```bash
python3 .workbuddy/skills/publish-article-to-blog/scripts/publish.py
```

脚本会：
1. 将新文章复制到 `docs/posts/`，若文章无 frontmatter 则自动生成（title/date/tags/category/description）；
2. 重写 `docs/posts/index.md` 文章列表（按分类分组、组内日期倒序）。

**注意**：脚本按文件名（`YYYY-MM-DD-标题.md`）解析日期与标题；`category` 通过关键词（Agent/Harness/LLM/大模型 → "AI Agent"）自动归类。若自动归类不准确，用 Edit 工具手动修正 frontmatter。

### Step 3: 更新侧边栏

`docs/.vitepress/config.mjs` 的 `themeConfig.sidebar` 需要手工为新文章添加条目（脚本只打印提示，不自动改 mjs 配置）。用 Edit 工具在对应分类 items 中添加：

```js
{ text: '文章标题', link: '/posts/文件名主体' },
```

- link 中不要带 `.md` 后缀（`cleanUrls: true`）。
- 若无对应分类的 sidebar 分组，先创建分组。

### Step 4: 本地构建验证

```bash
npm run build
```

- 构建必须成功（`build complete` 输出）才能推送。若失败，检查 frontmatter 语法（如 title 含特殊字符需加引号）或文章链接。
- 可先 `npm run dev` 本地预览确认排版。

### Step 5: 提交并推送

```bash
git add -A
git commit -m "feat: 发布文章《<标题>》"
git push origin main
```

- 推送后 GitHub Actions（`.github/workflows/deploy.yml`）自动构建并部署到 GitHub Pages。
- 可在推送后用 `gh run list --repo neobinary997/neobinary997.github.io` 观察部署状态。

### Step 6: 验证上线

- 等待约 1-2 分钟，访问 `https://neobinary997.github.io/posts/<文件名主体>` 确认 200。
- 用 `curl -s -o /dev/null -w "%{http_code}" <url>` 验证。

## 全自动模式

若用户要求"发布所有新文章并直接上线"，可一键执行（发布 + 构建 + 提交推送）：

```bash
python3 .workbuddy/skills/publish-article-to-blog/scripts/publish.py --auto
```

注意：`--auto` 仍不会更新侧边栏（Step 3），构建/推送前先补好侧边栏条目。

## 项目约定（务必遵守）

- **源目录**：`文章解读/`，命名 `YYYY-MM-DD-标题.md`。
- **目标目录**：`docs/posts/`，frontmatter 含 `title/date/tags/category/description`。
- **文章列表**：`docs/posts/index.md`（脚本自动维护）。
- **侧边栏**：`docs/.vitepress/config.mjs`（手动维护，见 Step 3）。
- **部署**：GitHub Actions + Pages，构建源为 workflow 模式，无需手动开启。
- **`.workbuddy/` 不入库**：已在 .gitignore，发布脚本本身在项目内但不会提交（除非用户要求）。

## Resources

### scripts/publish.py
核心发布脚本（Python 3 标准库，无需安装依赖）。负责迁移、frontmatter 生成、文章列表更新、可选构建与 git 推送。支持参数：`<文件名>` 指定单篇、`--dry-run` 预览、`--auto` 全自动。

### references/blog-structure.md
项目目录结构、frontmatter 规范、常见问题排查（构建失败、分类不准、链接 404 等）。
