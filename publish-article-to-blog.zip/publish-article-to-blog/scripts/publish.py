#!/usr/bin/env python3
"""
publish.py — 将《文章解读/》目录下的文章发布到 VitePress 博客（docs/posts/）。

功能：
1. 扫描 `文章解读/` 目录下的 .md 文件（支持单篇指定或全量）
2. 解析文件名（YYYY-MM-DD-标题.md）与文章内容，生成 frontmatter
3. 复制到 docs/posts/ 并写入 frontmatter
4. 更新 docs/posts/index.md 文章列表（按分类分组、按日期倒序）
5. 打印侧边栏需要更新的内容（供助手用 Edit 工具更新 config.mjs）

用法：
  python3 publish.py                          # 全量扫描并发布所有新文章
  python3 publish.py 文章文件路径.md           # 只发布指定文章
  python3 publish.py --dry-run                # 预览将要执行的操作（不写入）
  python3 publish.py --auto                   # 全自动：发布 + 构建 + git 提交推送

依赖：仅 Python 3 标准库。
"""

import argparse
import re
import shutil
import subprocess
import sys
from datetime import date
from pathlib import Path

# 项目根目录（脚本位于 .workbuddy/skills/publish-article-to-blog/scripts/）
SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_DIR = SCRIPT_DIR.parent
PROJECT_ROOT = SKILL_DIR.parent.parent.parent  # .workbuddy/skills/<name>/scripts -> 项目根

SOURCE_DIR = PROJECT_ROOT / "文章解读"
POSTS_DIR = PROJECT_ROOT / "docs" / "posts"
CONFIG_FILE = PROJECT_ROOT / "docs" / ".vitepress" / "config.mjs"

FILENAME_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})-(.+)\.md$")


def parse_filename(filename: str):
    """从文件名解析 (日期, 标题)。失败返回 (None, 标题=文件名主体)。"""
    m = FILENAME_RE.match(filename)
    if m:
        return m.group(1), m.group(2)
    return None, Path(filename).stem


def extract_frontmatter_fields(text: str, filename: str):
    """从文章内容与文件名提取 frontmatter 字段。"""
    file_date, file_title = parse_filename(filename)

    # 标题：优先取文章首个 # 一级标题，否则用文件名
    title = None
    for line in text.splitlines():
        if line.startswith("# "):
            title = line[2:].strip()
            break
    if not title:
        title = file_title

    # 日期：文件名日期优先，否则取文件修改日期
    article_date = file_date or date.fromtimestamp(
        (SOURCE_DIR / filename).stat().st_mtime
    ).isoformat()

    # 分类：文件名/正文中是否含 Agent 等关键词（可扩展）
    category = "其他"
    if re.search(r"Agent|Harness|LLM|大模型", text):
        category = "AI Agent"

    # 描述：取正文中「一句话概括」引用行
    description = ""
    for line in text.splitlines():
        s = line.strip()
        if "一句话概括" in s or s.startswith("> **一句话"):
            description = s.lstrip(">").strip()
            break
    description = re.sub(r"^.*?一句话概括[^:：]*[:：]\s*", "", description)

    # 标签
    tags = ["未分类"]
    if category != "其他":
        tags = [category]

    return title, article_date, category, description, tags


def build_frontmatter(title, article_date, category, description, tags):
    lines = ["---", f"title: {title}", f"date: {article_date}"]
    lines.append("tags:")
    for t in tags:
        lines.append(f"  - {t}")
    lines.append(f"category: {category}")
    if description:
        lines.append(f"description: {description}")
    lines.append("---")
    lines.append("")
    return "\n".join(lines)


def is_published(filename: str) -> bool:
    return (POSTS_DIR / filename).exists()


def publish_one(filename: str, dry_run: bool) -> bool:
    """发布单篇文章，返回是否发布了新文章。"""
    src = SOURCE_DIR / filename
    dst = POSTS_DIR / filename

    if is_published(filename):
        print(f"  [跳过] 已发布: {filename}")
        return False

    text = src.read_text(encoding="utf-8")
    title, article_date, category, description, tags = extract_frontmatter_fields(text, filename)

    # 若文章已有 frontmatter，不再重复添加
    if text.startswith("---"):
        content = text
        print(f"  [发布] {filename} (已含 frontmatter)")
    else:
        content = build_frontmatter(title, article_date, category, description, tags) + text
        print(f"  [发布] {filename} → title={title!r}, date={article_date}, category={category}")

    if not dry_run:
        dst.write_text(content, encoding="utf-8")
    return True


def update_index(published: list, dry_run: bool):
    """更新 docs/posts/index.md 文章列表。"""
    if not published:
        return

    index_file = POSTS_DIR / "index.md"
    old = index_file.read_text(encoding="utf-8") if index_file.exists() else ""

    # 收集所有文章（含已有的）
    items = []
    for f in sorted(POSTS_DIR.glob("*.md")):
        if f.name == "index.md":
            continue
        text = f.read_text(encoding="utf-8")
        date_str, title = parse_filename(f.name)
        if not title:
            continue
        m = re.search(r"^category:\s*(.+)$", text, re.MULTILINE)
        category = m.group(1).strip() if m else "其他"
        items.append((date_str or "", title, category, f.stem))

    # 按分类分组、组内按日期倒序
    groups = {}
    for d, t, c, stem in items:
        groups.setdefault(c, []).append((d, t, stem))
    for c in groups:
        groups[c].sort(key=lambda x: x[0], reverse=True)

    lines = ["---", "title: 文章列表", "---", "", "# 文章列表", ""]
    for cat in sorted(groups):
        lines.append(f"## {cat}")
        lines.append("")
        for d, t, stem in groups[cat]:
            lines.append(f"- {t}（{d}） → [阅读](./{stem})")
        lines.append("")

    new = "\n".join(lines)
    if old != new:
        print(f"  [索引] 更新 docs/posts/index.md（{len(items)} 篇文章，{len(groups)} 个分类）")
        if not dry_run:
            index_file.write_text(new, encoding="utf-8")


def print_sidebar_hint():
    """打印侧边栏更新建议，供助手用 Edit 更新 config.mjs。"""
    print("\n[提示] 请用 Edit 工具在 docs/.vitepress/config.mjs 的 sidebar 中为新文章添加条目，例如：")
    print("  { text: '<文章标题>', link: '/posts/<文件名主体>' },")


def run(cmd: list, cwd: Path):
    print(f"  $ {' '.join(cmd)}")
    return subprocess.run(cmd, cwd=cwd, check=False).returncode


def main():
    parser = argparse.ArgumentParser(description="发布文章到 VitePress 博客")
    parser.add_argument("file", nargs="?", help="指定文章文件名（可省略，缺省全量扫描）")
    parser.add_argument("--dry-run", action="store_true", help="仅预览不写入")
    parser.add_argument("--auto", action="store_true", help="发布后自动构建并 git 提交推送")
    args = parser.parse_args()

    if not SOURCE_DIR.exists():
        print(f"错误：源目录不存在 {SOURCE_DIR}")
        sys.exit(1)
    POSTS_DIR.mkdir(parents=True, exist_ok=True)

    files = [args.file] if args.file else [
        f.name for f in sorted(SOURCE_DIR.glob("*.md"))
    ]

    published = []
    print(f"源目录: {SOURCE_DIR}")
    print(f"目标目录: {POSTS_DIR}")
    for f in files:
        if not (SOURCE_DIR / f).exists():
            print(f"  [错误] 文件不存在: {f}")
            continue
        if publish_one(f, args.dry_run):
            published.append(f)

    update_index(published, args.dry_run)
    print_sidebar_hint()

    if args.auto and published and not args.dry_run:
        print("\n[构建]")
        run(["npm", "run", "build"], PROJECT_ROOT)
        print("\n[Git]")
        run(["git", "add", "-A"], PROJECT_ROOT)
        run(["git", "commit", "-m", f"feat: 发布文章 {len(published)} 篇"], PROJECT_ROOT)
        run(["git", "push", "origin", "main"], PROJECT_ROOT)
        print("\n✅ 发布完成！GitHub Actions 将自动部署到 GitHub Pages。")

    if args.dry_run:
        print("\n(dry-run 模式，未写入任何文件)")


if __name__ == "__main__":
    main()
